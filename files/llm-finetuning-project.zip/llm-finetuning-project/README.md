# LLM Fine-Tuning with LoRA

> Fine-tuning a small language model on a custom dataset — no GPU required.

## What this project does

This project fine-tunes **SmolLM2-135M-Instruct** (a 135 million parameter model by HuggingFace) on a custom Machine Learning Q&A dataset using **LoRA** (Low-Rank Adaptation). The entire workflow runs on CPU with 16 GB RAM.

The result is a small chatbot that answers ML questions in the style and depth of the training data.

## What I learned building this

- How **LoRA** works: instead of updating all model weights, LoRA inserts small trainable "adapter" matrices. Only ~0.5% of parameters are trained, making this feasible on a laptop.
- The HuggingFace ecosystem: `transformers`, `peft`, `datasets`, `accelerate`
- How to format data for causal language model fine-tuning (JSONL format)
- The training loop: tokenisation → loss → gradient descent → saving adapters
- How to load a LoRA adapter on top of a base model for inference

## Project structure

```
llm-finetuning-project/
├── data/
│   ├── train.jsonl        # 30 ML Q&A training examples
│   └── README.md          # Dataset description
├── scripts/
│   ├── train.py           # LoRA fine-tuning (run this first)
│   └── chat.py            # Interactive chat with the fine-tuned model
├── outputs/               # Adapter saved here after training (git-ignored)
├── requirements.txt
└── README.md
```

## Setup and usage

**1. Clone and create virtual environment**
```bash
git clone https://github.com/YOUR_USERNAME/llm-finetuning-project.git
cd llm-finetuning-project

# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python -m venv venv
source venv/bin/activate
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. Fine-tune the model**
```bash
python scripts/train.py
```
First run downloads SmolLM2-135M (~270 MB). Training takes ~5–15 minutes on CPU.

**4. Chat with your fine-tuned model**
```bash
python scripts/chat.py
```

## Technical details

| Setting | Value |
|---|---|
| Base model | HuggingFaceTB/SmolLM2-135M-Instruct |
| Fine-tuning method | LoRA (PEFT) |
| LoRA rank | 8 |
| Target modules | q_proj, v_proj |
| Trainable parameters | ~0.5% of total |
| Training epochs | 3 |
| Hardware | CPU only |

## Dataset

30 hand-crafted ML Q&A pairs in JSONL format:
```json
{"input": "What is overfitting?", "output": "Overfitting happens when a model memorises the training data too closely..."}
```

See `data/README.md` for more details.

## Next steps / ideas

- [ ] Expand dataset to 200+ examples for better quality
- [ ] Try TinyLlama-1.1B for a larger model
- [ ] Add a Gradio web interface (`pip install gradio`)
- [ ] Upload the LoRA adapter to HuggingFace Hub
- [ ] Experiment with different LoRA ranks (4, 16, 32)

## Requirements

- Python 3.10
- 16 GB RAM (8 GB minimum)
- No GPU required
