# Training Data

## Format

Each line in `train.jsonl` is a JSON object with two fields:

```json
{"input": "your question here", "output": "the answer here"}
```

This is called **JSONL** (JSON Lines) — one JSON object per line. It is the standard format for fine-tuning datasets.

## This dataset

30 hand-crafted Machine Learning Q&A pairs covering:

- Core concepts (supervised, unsupervised, reinforcement learning)
- Neural network components (layers, activation, dropout, batch norm)
- Model training (loss functions, gradient descent, learning rate)
- Common problems (overfitting, underfitting, regularisation)
- Modern architectures (transformers, attention, LLMs)
- Fine-tuning methods (transfer learning, LoRA)

## How to extend it

Add more lines to `train.jsonl` in the same format. Tips:

1. Keep answers in a consistent style and length
2. Aim for 50–200 examples for a first project
3. Cover edge cases and variations of questions you expect
4. Avoid contradictory answers

## Data splits

This project uses all data for training (no validation split) to keep it simple. For a production project you would hold out 10–20% for validation.
